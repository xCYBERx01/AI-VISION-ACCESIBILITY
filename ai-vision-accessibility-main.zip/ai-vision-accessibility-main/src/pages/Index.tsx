import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { BookOpen, Eye, AlertTriangle, RefreshCw, Volume2, VolumeX, Loader2 } from "lucide-react";
import { toast } from "sonner";

type Mode = "read" | "describe" | "hazard";
type Facing = "environment" | "user";

const MODE_META: Record<Mode, { label: string; icon: typeof BookOpen; hint: string }> = {
  read: { label: "Read Text", icon: BookOpen, hint: "Reads any text in view" },
  describe: { label: "Describe Scene", icon: Eye, hint: "Describes surroundings" },
  hazard: { label: "Detect Hazards", icon: AlertTriangle, hint: "Warns about obstacles" },
};

export default function Index() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const [facing, setFacing] = useState<Facing>("environment");
  const [streamReady, setStreamReady] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<Mode | null>(null);
  const [lastResult, setLastResult] = useState<{ mode: Mode; text: string } | null>(null);
  const [voiceOn, setVoiceOn] = useState(true);

  const startCamera = useCallback(async (f: Facing) => {
    setError(null);
    setStreamReady(false);
    streamRef.current?.getTracks().forEach(t => t.stop());
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: f } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        setStreamReady(true);
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Camera unavailable";
      setError(msg);
      speak("Camera unavailable. Please grant camera permission.");
    }
  }, []);

  useEffect(() => {
    startCamera(facing);
    return () => { streamRef.current?.getTracks().forEach(t => t.stop()); };
  }, [facing, startCamera]);

  // Stop any speech on unmount
  useEffect(() => () => { try { window.speechSynthesis.cancel(); } catch {} }, []);

  function speak(text: string) {
    if (!voiceOn || !text) return;
    try {
      window.speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.rate = 1.05;
      u.pitch = 1;
      u.volume = 1;
      window.speechSynthesis.speak(u);
    } catch {}
  }

  function captureFrame(): string | null {
    const v = videoRef.current, c = canvasRef.current;
    if (!v || !c || !v.videoWidth) return null;
    // Downscale to keep payload small
    const maxW = 1024;
    const scale = Math.min(1, maxW / v.videoWidth);
    const w = Math.round(v.videoWidth * scale);
    const h = Math.round(v.videoHeight * scale);
    c.width = w; c.height = h;
    const ctx = c.getContext("2d");
    if (!ctx) return null;
    ctx.drawImage(v, 0, 0, w, h);
    return c.toDataURL("image/jpeg", 0.8);
  }

  async function runMode(mode: Mode) {
    if (busy) return;
    if (!streamReady) {
      speak("Camera not ready.");
      return;
    }
    const img = captureFrame();
    if (!img) {
      toast.error("Could not capture frame");
      return;
    }
    setBusy(mode);
    speak(mode === "read" ? "Reading text." : mode === "describe" ? "Describing scene." : "Scanning for hazards.");
    try {
      const { data, error } = await supabase.functions.invoke("analyze-vision", {
        body: { imageBase64: img, mode },
      });
      if (error) throw error;
      const text: string = data?.text || "No response.";
      setLastResult({ mode, text });
      speak(text);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Analysis failed";
      toast.error(msg);
      speak("Analysis failed. Please try again.");
    } finally {
      setBusy(null);
    }
  }

  function toggleVoice() {
    setVoiceOn(v => {
      const next = !v;
      if (!next) try { window.speechSynthesis.cancel(); } catch {}
      else {
        const u = new SpeechSynthesisUtterance("Voice on");
        try { window.speechSynthesis.speak(u); } catch {}
      }
      return next;
    });
  }

  function flipCamera() {
    setFacing(f => (f === "environment" ? "user" : "environment"));
    speak(facing === "environment" ? "Front camera" : "Rear camera");
  }

  return (
    <main className="fixed inset-0 text-foreground flex flex-col overflow-hidden">
      <h1 className="sr-only">VisionAid — accessibility assistant</h1>

      {/* Camera area */}
      <section
        className="relative flex-1 overflow-hidden"
        aria-label="Live camera feed"
      >
        <video
          ref={videoRef}
          playsInline
          muted
          className={`absolute inset-0 w-full h-full object-cover ${facing === "user" ? "scale-x-[-1]" : ""}`}
        />
        <canvas ref={canvasRef} className="hidden" />

        {/* Subtle vignette for depth */}
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_55%,hsl(222_50%_0%/0.55)_100%)]" />

        {/* Top bar */}
        <div className="absolute top-0 inset-x-0 p-4 pt-[max(1rem,env(safe-area-inset-top))] flex items-center justify-between gap-3">
          <div className="glass px-4 py-2.5 rounded-2xl flex items-center gap-2">
            <span className="size-2 rounded-full bg-primary shadow-[0_0_12px_hsl(var(--primary))]" aria-hidden />
            <span className="text-sm font-semibold tracking-wide">VisionAid</span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={toggleVoice}
              aria-label={voiceOn ? "Turn voice off" : "Turn voice on"}
              aria-pressed={voiceOn}
              className="glass min-h-12 min-w-12 rounded-2xl flex items-center justify-center transition-transform active:scale-95 hover:bg-white/10"
            >
              {voiceOn ? <Volume2 className="size-5" /> : <VolumeX className="size-5" />}
            </button>
            <button
              onClick={flipCamera}
              aria-label="Switch camera"
              className="glass min-h-12 min-w-12 rounded-2xl flex items-center justify-center transition-transform active:scale-95 hover:bg-white/10"
            >
              <RefreshCw className="size-5" />
            </button>
          </div>
        </div>

        {/* Center status */}
        {!streamReady && !error && (
          <div className="absolute inset-0 flex items-center justify-center" role="status" aria-live="polite">
            <p className="glass-strong text-foreground/90 text-base font-medium px-6 py-3 rounded-2xl">
              Starting camera…
            </p>
          </div>
        )}
        {error && (
          <div className="absolute inset-0 flex items-center justify-center px-6" role="alert">
            <p className="glass-strong text-foreground text-base font-medium text-center p-5 rounded-2xl border border-destructive/60 max-w-sm">
              {error}
            </p>
          </div>
        )}

        {/* Result overlay */}
        {(lastResult || busy) && (
          <div
            className="absolute bottom-4 inset-x-4 glass-strong rounded-3xl p-5"
            role="region"
            aria-live="polite"
            aria-label="Analysis result"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-[11px] uppercase tracking-[0.18em] font-bold text-primary">
                {busy ? `${MODE_META[busy].label}` : lastResult ? MODE_META[lastResult.mode].label : ""}
              </span>
              {busy && <Loader2 className="size-4 animate-spin text-primary" aria-hidden />}
            </div>
            {lastResult && !busy && (
              <p className="mt-2 text-lg font-medium leading-snug text-foreground/95">{lastResult.text}</p>
            )}
          </div>
        )}
      </section>

      {/* Action bar */}
      <nav
        aria-label="Vision actions"
        className="glass-strong border-t border-white/10 px-4 py-4 pb-[max(1rem,env(safe-area-inset-bottom))]"
      >
        <div className="grid grid-cols-3 gap-3 max-w-xl mx-auto">
          {(Object.keys(MODE_META) as Mode[]).map(m => {
            const Icon = MODE_META[m].icon;
            const active = busy === m;
            return (
              <button
                key={m}
                onClick={() => runMode(m)}
                disabled={!!busy || !streamReady}
                aria-label={`${MODE_META[m].label}. ${MODE_META[m].hint}`}
                className="convex-primary min-h-[88px] rounded-2xl font-semibold text-sm flex flex-col items-center justify-center gap-1.5 px-2 disabled:opacity-50 disabled:cursor-not-allowed active:scale-[0.97] transition-transform"
              >
                {active ? <Loader2 className="size-7 animate-spin" /> : <Icon className="size-7" aria-hidden />}
                <span className="leading-tight text-center">{MODE_META[m].label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </main>
  );
}
