// Vision analysis edge function — uses Lovable AI (Gemini) for OCR, scene description, and hazard detection.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

type Mode = "read" | "describe" | "hazard";

const PROMPTS: Record<Mode, string> = {
  read:
    "You are an OCR assistant for a blind user. Read aloud ALL legible text in the image, exactly as written, in natural reading order. If multiple blocks exist, separate them with a short pause using a period. If there is no readable text, say exactly: 'No readable text detected.' Do not add commentary, do not describe the scene, do not mention images. Output plain text only, suitable for text-to-speech.",
  describe:
    "You are a scene description assistant for a blind user. In 1-3 short sentences, describe the most important elements of the scene: people (count, posture), key objects, setting, and lighting. Be concrete and specific. Do not speculate. Do not start with 'The image shows' — speak directly. Output plain text only, suitable for text-to-speech.",
  hazard:
    "You are a safety assistant for a blind user walking or moving. Identify any immediate hazards or obstacles: steps, stairs, curbs, doors, low ceilings, wet floors, traffic, vehicles, people in path, sharp objects, drop-offs, holes. Respond in 1-2 short, urgent sentences starting with the most important hazard and its rough position (left, center, right, ahead). If the path appears clear, say exactly: 'Path appears clear.' Output plain text only, suitable for text-to-speech.",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { imageBase64, mode } = await req.json();
    if (!imageBase64 || typeof imageBase64 !== "string") {
      return json({ error: "imageBase64 required" }, 400);
    }
    const m: Mode = (mode === "read" || mode === "describe" || mode === "hazard") ? mode : "describe";

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) return json({ error: "LOVABLE_API_KEY not configured" }, 500);

    const dataUrl = imageBase64.startsWith("data:") ? imageBase64 : `data:image/jpeg;base64,${imageBase64}`;

    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: PROMPTS[m] },
          {
            role: "user",
            content: [
              { type: "text", text: "Analyze this image now." },
              { type: "image_url", image_url: { url: dataUrl } },
            ],
          },
        ],
      }),
    });

    if (!resp.ok) {
      if (resp.status === 429) return json({ error: "Rate limit exceeded. Please wait a moment." }, 429);
      if (resp.status === 402) return json({ error: "AI credits exhausted. Add credits in Workspace > Usage." }, 402);
      const t = await resp.text();
      console.error("AI gateway error", resp.status, t);
      return json({ error: "AI gateway error" }, 500);
    }

    const data = await resp.json();
    const text: string = data?.choices?.[0]?.message?.content?.trim() || "No response.";
    return json({ text, mode: m });
  } catch (e) {
    console.error("analyze-vision error", e);
    return json({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
